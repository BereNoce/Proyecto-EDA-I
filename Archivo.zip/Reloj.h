#ifndef RELOJ_H_INCLUDED
#define RELOJ_H_INCLUDED

#include <stdlib.h>
#include <stdio.h>
#include <stdbool.h>
#include <assert.h>
#include <time.h>
#include <string.h>
#include <unistd.h>



typedef struct
{
	int horas;
	int minutos;
	int segundos;
} Reloj;

Reloj* Crear_Reloj( int horas, int minutos, int segundos);
void Reloj_SetHoras( Reloj* this, int horas );
void Reloj_SetMinutos( Reloj* this, int minutos );
void Reloj_SetSegundos( Reloj* this, int segundos );
void Reloj_Imprime( const Reloj* this );
void Reloj_Poner( Reloj* this, int horas, int minutos, int segundos );
int Reloj_GetHoras (Reloj* this);
int Reloj_GetMinutos (Reloj* this);
int Reloj_GetSegundos (Reloj* this);

#endif