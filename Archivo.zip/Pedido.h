
#ifndef  PEDIDO_INC
#define  PEDIDO_INC

#include <stdlib.h>
#include <stdio.h>
#include <stdbool.h>
#include <assert.h>
#include <time.h>
#include <string.h>
#include <unistd.h>


#include "Reloj.h"
#include "Producto.h"

#define MAX_LENGTH 20


#define TIPOS 3
#define SABORES 3
#define EXTRAS 3
#define NOMBRE_MAX 20

typedef struct {
    
    int Pizzas[TIPOS];
    int Bebidas[SABORES]; 
    int Postres[EXTRAS];
    size_t Numero;
    Reloj Hora;
    float Total;
    char Nombre[NOMBRE_MAX]; 
} Pedido;

typedef struct Order
{
  Pedido data;
  struct Order* next;
  struct Order* prev;
} Order;

typedef struct Pedidos
{
  Order* first;
  Order* last;
  Order* cursor;
  size_t len;
} Pedidos;


// **Listas doblemente enlazadas** //
static Order* Pedido_NewOrder( Pedido x );
Pedidos* Pedido_NewLista();
void Pedido_DeleteLista( Pedidos** this );
void Pedido_Agregar( Pedidos* this, Pedido item );
void Pedido_Quitar( Pedidos* this );
void Pedido_Quitar_PedidoBack( Pedidos* this );
void Pedido_Cancelar( Pedidos* this );   
void Pedido_CursorProximo( Pedidos* this );
void Pedido_CursorUltimo( Pedidos* this );
void Pedido_CursorNext( Pedidos* this );
bool Pedido_IsEmpty( Pedidos* this );
size_t Pedido_Numero( Pedidos* this );
void Pedido_Vaciar( Pedidos* this );
Pedido Pedido_Dar_Proximo_Pedido( Pedidos* this );
Pedido Pedido_Dar_Ultimo_Pedido( Pedidos* this );
Pedido Pedido_Cursor( Pedidos* this );

    // ***Pedidos*** //
int Pedidos_Menu();
int Pedidos_MenuPizza();
int Pedidos_MenuBebida();
int Pedidos_MenuPostres();
bool Pedidos_Volver_a_Pedir();
int Pedidos_Cantidad();
Pedido Pedidos_Toma_De_Pedido( float Precios_Pizzas[], float Precios_Bebidas[], float Precios_Postres[] , size_t* acum);
float Pedido_Dar_la_Cuenta( Pedido this, float Precios_Pizzas[], float Precios_Bebidas[], float Precios_Postres[] );
Pedido* Pedidos_Buscar_Pedio( Pedidos* this, int Len, char Name[NOMBRE_MAX] );
void Pedidos_agregarHoraPedido(Pedido* Order);
void Pedidos_ResumDia( Pedidos* this );  
void Pedidos_Print_Pedido ( Pedido this );
void Pedidos_Nombre_Pedido( Pedido* this, char* name);
void Pedidos_Venta_del_Dia( Pedidos* this);

    

#endif   /* ----- #ifndef PEDIDO_INC  ----- */
