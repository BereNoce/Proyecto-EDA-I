#include "Pedido.h"

// **Listas doblemente enlazadas** //

/**
 * The function creates a new Order node with the given data and returns a   
 * pointer to it.
 * 
 * @param x The parameter "x" is of type "Pedido" and is used to initialize 
 * the "data" field of the newly created "Order" struct.
 * 
 * @return a pointer to an Order struct.
 */
static Order* Pedido_NewOrder( Pedido x )
{
   Order* n = (Order*) malloc( sizeof( Order ) );
   if( n != NULL ){
      n->data = x;
      n->next = NULL;
      n->prev = NULL;
   }

   return n;
}

/**
 * The function creates a new doubly linked list for storing orders.
 * 
 * @return A pointer to a newly created doubly linked list of type "Pedidos".
 */
Pedidos* Pedido_NewLista(){
    Pedidos* dll = (Pedidos*) malloc( sizeof( Pedidos ) );
    if( dll != NULL )
    {
        dll->first = dll->last = dll->cursor = NULL;
        dll->len = 0;
    }
    return dll;
}

/**
 * This function deletes a linked list of orders and sets the pointer to   
 * NULL.
 * 
 * @param this a pointer to a pointer to a struct of type Pedidos, which 
 * represents a linked list of orders.
 */
void Pedido_DeleteLista( Pedidos** this ){
    assert( *this );
    Pedido_Vaciar( *this );
    free( *this );
    *this = NULL;
}

/**
 * The function adds a new order to a list of orders.
 * 
 * @param this a pointer to a struct of type Pedidos, which represents a 
 * collection of orders
 * @param item The parameter "item" is of type "Pedido" and represents the 
 * order that needs to be added
 * to the list of orders.
 */
void Pedido_Agregar( Pedidos* this, Pedido item ){
  
   Order* n = Pedido_NewOrder( item );
   assert( n );

   if( this->first != NULL ){

      this->last->next = n;
      n->prev = this->last;
      this->last = n;
   } else{
      this->first = this->last = this->cursor = n;
   }
   ++this->len;
}

/**
 * This function removes the first element of a linked list of orders and 
 * updates the list's length and
 * pointers accordingly.
 * 
 * @param this a pointer to a struct of type Pedidos, which represents a list of orders.
 */
void Pedido_Quitar( Pedidos* this ){
    assert( this->first != NULL );
    if( this->last != this->first ){
        Order* x = this->first->next;
        free( this->first );
        x->prev = NULL;
        this->first= x;
        --this->len;
    } else{
        free( this->first );
        this->first = this->last = this->cursor = NULL;
        
    }
}


void Pedido_Quitar_PedidoBack( Pedidos* this ){
    assert( this->last != NULL );
    if( this->last != this->first ){
        Order* x = this->last->prev;
        free( this->last );
        x->next = NULL;
        this->last= x;
        --this->len;
    } else{
        free( this->first );
        this->first = this->last = this->cursor = NULL;
        
    }
}


/**
 * The function cancels a specific order from a linked list of orders.
 * 
 * @param this a pointer to a struct of type Pedidos, which represents a 
 * list of orders.
 * 
 * @return If the cursor is NULL, the function will return without doing 
 * anything. There is no explicit return statement for other cases.
 */
void Pedido_Cancelar( Pedidos* this ){
    assert( this->cursor );
    if (this->cursor == NULL) { 
        return;
        
    }
    Order* order_to_delete = this->cursor;
    
    if ( order_to_delete == this->first && order_to_delete == this->last ) { 
        this->first = NULL;
        this->last = NULL;
    } else if (order_to_delete == this->first) { 
        this->first = order_to_delete->next;
        this->first->prev = NULL;     
    } else if (order_to_delete == this->last) {
        this->last = order_to_delete->prev;
        this->last->next = NULL;
    } else {
        order_to_delete->prev->next = order_to_delete->next;
        order_to_delete->next->prev = order_to_delete->prev;
    }
    this->cursor = order_to_delete->next;
    free(order_to_delete);
    this->len--;
}

/**
 * This function sets the cursor of a Pedidos struct to the first element.
 * 
 * @param this The "this" parameter is a pointer to an instance of the 
 * "Pedidos" struct. The function "Cursor_Pedido_Proximo" sets the cursor of 
 * the "Pedidos" struct to the first element of the linked list.
 */
void Pedido_CursorProximo( Pedidos* this ){
    this->cursor = this->first;
}

/**
 * This function sets the cursor of a Pedidos struct to the last element.
 * 
 * @param this A pointer to an instance of the struct Pedidos.
 */
void Pedido_CursorUltimo( Pedidos* this ){
    this->cursor = this->last;
}

/**
 * The function moves the cursor to the next node in a linked list of orders.
 * 
 * @param this a pointer to a Pedidos struct, which contains a linked list 
 * of Order structs and a cursor pointer to the current node in the list.
 */
void Pedido_CursorNext( Pedidos* this ){
    assert( this->cursor != NULL );
    Order* n = this->cursor->next;
    this->cursor = n;
    
}

/**
 * The function checks if a linked list of orders is empty.
 * 
 * @param this The "this" parameter in this function is a pointer to a 
 * struct of type "Pedidos". It is used to refer to the current instance of 
 * the struct on which the function is being called.
 * 
 * @return The function `Pedidos_IsEmpty` is returning a boolean value. It 
 * returns `true` if the `first` element of the `Pedidos` struct pointed to 
 * by `this` is `NULL`, indicating that the list is empty. Otherwise, it 
 * returns `false`.
 */
bool Pedidos_IsEmpty( Pedidos* this ){
    return this->first == NULL;
}

/**
 * The function returns the length of a given array of orders.
 * 
 * @param this a pointer to a struct of type Pedidos.
 * 
 * @return The function `Numero_De_Pedidos` is returning the length of the 
 * `Pedidos` object, which is of type `size_t`.
 */
size_t Pedido_Numero( Pedidos* this ){
    return this->len;
}

/**
 * The function Vaciar_Pedidos removes all elements from a linked list of 
 * Pedidos.
 * 
 * @param this A pointer to a struct of type Pedidos.
 */
void Pedido_Vaciar( Pedidos* this ){
    assert ( this->first != NULL );
    while( Pedidos_IsEmpty( this ) == 0 ){
        Pedido_Quitar( this );
    }
}

/**
 * The function returns the data of the first element in a linked list of 
 * orders.
 * 
 * @param this a pointer to a struct of type Pedidos, which contains 
 * information about a list of orders.
 * 
 * @return the data of the first node in the linked list of orders.
 */
Pedido Pedido_Dar_Proximo_Pedido( Pedidos* this ){
  
    assert( this->first != NULL );
    return this->first->data;
}

/**
 * The function returns the data of the last element in a linked list of 
 * orders.
 * 
 * @param this a pointer to a struct of type Pedidos, which contains 
 * information about a list of orders.
 * 
 * @return the data of the last element in the linked list of orders 
 * (Pedidos).
 */
Pedido Pedido_Dar_Ultimo_Pedido( Pedidos* this ){
    assert( this->last != NULL);
    return this->last->data;
}

/**
 * The function returns the data of the current cursor position in a linked 
 * list of orders.
 * 
 * @param this The "this" parameter is a pointer to an instance of the 
 * "Pedidos" struct. It is used to access the data members and member 
 * functions of the struct.
 * 
 * @return The function `Pedido_Cursor` is returning the data of the current 
 * node pointed to by the cursor in the linked list `this`.
 */
Pedido Pedido_Cursor( Pedidos* this ){
    return this->cursor->data;
}
  
    // ***Pedidos*** //

/**
 * The function displays a menu for ordering food items and returns the 
 * user's choice.
 * 
 * @return an integer value, which is the user's choice of option for their 
 * order.
 */
int Pedidos_Menu(){
    int respuesta = 0;
    
    etiqueta1:
    printf( "¿Qué opcion deseas ordenar?\n" );
    printf( "[1]Pizza\n" );
    printf( "[2]Bebida\n" );
    printf( "[3]Postre\n" );
  
    printf( "\n" );
    printf( "[4]Salir\n" );
    scanf("%d", &respuesta );
    
    if( respuesta > 4 ){
    printf ( "Dato erroneo\n ");
    goto etiqueta1;
    }
    
    printf( "\n" );
    return respuesta;
}

/**
 * The function displays a menu for selecting a type of pizza and returns 
 * the user's choice.
 * 
 * @return an integer value, which is the user's choice of pizza type (1 for 
 * pepperoni, 2 for Hawaiian, or 3 to exit to the main menu).
 */
int Pedidos_MenuPizza(){
  
  int respuesta = 0;
  etiqueta1:
  printf( "¿Qué tipo de pizza deseas ordenar?\n" );
  printf( "[1]Margarita\n" );
  printf( "[2]Peperoni\n" );
  printf( "[3]Hawayana\n" );
  printf( "\n" );
  printf( "[4]Salir al menu\n" );
  scanf("%d", &respuesta );
  
  if( respuesta > 4 ){
    printf ( "Dato erróneo\n ");
    goto etiqueta1;
  }  
  printf( "\n" );
  return respuesta;
}

/**
 * The function displays a menu for selecting a type of beverage and returns 
 * the user's choice.
 * 
 * @return an integer value, which is the user's choice of beverage from the 
 * menu.
 */
int Pedidos_MenuBebida(){
  int respuesta = 0;
  etiqueta1:
  printf( "¿Qué tipo de bebida deseas ordenar?\n" );
  printf( "[1]Cocacola\n" );
  printf( "[2]Refresco de cola\n" );
  printf( "[3]Agua natural\n" );
  printf( "\n" );
  printf( "[4]Salir al menu\n" );
  scanf("%d", &respuesta );
  
  if( respuesta > 4 ){
    printf ( "Dato erróneo\n ");
    goto etiqueta1;
  }
    
  printf( "\n" );
  return respuesta;
}

/**
 * The function displays a menu for selecting a type of dessert and returns 
 * the user's choice.
 * 
 * @return an integer value, which is the user's choice for the type of 
 * dessert they want to order.
 */
int Pedidos_MenuPostres(){
  int respuesta = 0;
  etiqueta1:
  printf( "¿Qué tipo de postre deseas ordenar?\n" );
  printf( "[1]Papas a la francesa\n" );
  printf( "[2]Alitas\n" );
  printf( "[3]Pudin\n" );
  printf( "\n" );
  printf( "[4]Salir al menu\n" );
  scanf("%d", &respuesta );
  
  if( respuesta > 4 ){
    printf ( "Dato erróneo\n ");
    goto etiqueta1;
  }
    
  printf( "\n" );
  return respuesta;
}

/**
 * The function asks the user if they want to continue and returns a boolean 
 * value based on their response.
 * 
 * @return a boolean value (true or false) depending on the user's input. If 
 * the user inputs 1, the function returns true. If the user inputs 2, the 
 * function returns false. If the user inputs any other value, the function 
 * prints an error message and goes back to the beginning of the function
 * using a label and a goto statement.
 */
bool Pedidos_Volver_a_Pedir(){

  int respuesta = 0;
  etiqueta1:
  printf( "¿Seria todo?\n" );
  printf( "[1]Si\n" );
  printf( "[2]No\n" );
  scanf("%d", &respuesta );
    
  if( respuesta == 1 )
  {
    return true;
  }else if( respuesta == 2 ){
    return false;
  }else{
    printf(" Dato erróneo \n");
    goto etiqueta1;
  }
}

/**
 * The function "Cantidad" asks the user for a quantity and returns the 
 * input as an integer.
 * 
 * @return The function "Cantidad" is returning an integer value. 
 * Specifically, it is returning the value of the variable "respuesta".
 */
int Pedidos_Cantidad(){
    int respuesta;
    printf( "¿Cuantas seran?\n");
    scanf("%d", &respuesta);
    return respuesta;
}

/**
 * The function takes a pointer to an accumulator and returns a Pedido 
 * object representing a customer's order, with options for selecting pizzas, drinks, and desserts.
 * 
 * @param acum A pointer to a size_t variable that keeps track of the total 
 * of orders received.
 * The function increments this variable before assigning it to the order 
 * number of the current order.
 * 
 * @return a variable of type "Pedido".
 */

Pedido Pedidos_Toma_De_Pedido( float Precios_Pizzas[], float Precios_Bebidas[], float Precios_Postres[] , size_t* acum){
  ++acum;
  //etiqueta1:
  Pedido Order;
  int opcion;
  int opcion2 = 0; 
  int opcion3 = 0; 
  int opcion4 = 0;
  etiqueta1:
  opcion = Pedidos_Menu();
 
  switch ( opcion ){
    
    case 1:
      etiqueta2:
      opcion2 = Pedidos_MenuPizza();
      Order.Pizzas[ opcion2 - 1 ] = Pedidos_Cantidad();
      if( Pedidos_Volver_a_Pedir() == false ){
        goto etiqueta2;
      }
      break;

    case 2:
      etiqueta3:
      opcion3 = Pedidos_MenuBebida();
      Order.Bebidas[ opcion3 - 1 ] = Pedidos_Cantidad();
      if( Pedidos_Volver_a_Pedir() == false ){
        goto etiqueta1;
      }
      break;
    
    case 3:
      etiqueta4:
      opcion4 = Pedidos_MenuPostres();
      Order.Postres[ opcion3 - 1 ] = Pedidos_Cantidad();
      if( Pedidos_Volver_a_Pedir() == false ){
        goto etiqueta1;
      }
      break;
    
    case 4:
      //Aqui se debe salir al menu principal
      break;
    
    default:
      printf("Dato erróneo\n");
      goto etiqueta1;
      break;
    
  }

  Pedidos_agregarHoraPedido( &Order );
  Order.Numero = acum;
  Order.Total = Pedido_Dar_la_Cuenta( Order, Precios_Pizzas, Precios_Bebidas, Precios_Postres);
  Pedidos_agregarHoraPedido( &Order );
  char Name[NOMBRE_MAX];
  printf( "¿Ha nombre de quien es el pedido?\n");
  scanf( "%s", Name);
  Pedidos_Nombre_Pedido( &Order, Name);
  
  return Order;
  
  
}

/**
 * This function calculates the total cost of an order based on the quantities of pizzas, beverages, and desserts
 * in the given `Pedido` object and the corresponding price arrays.
 * 
 * @param this The `Pedido` object representing the order.
 * @param Precios_Pizzas An array of `float` values representing the prices of pizzas.
 * @param Precios_Bebidas An array of `float` values representing the prices of beverages.
 * @param Precios_Postres An array of `float` values representing the prices of desserts.
 * 
 * @return The total cost of the order as a `float` value.
 */
float Pedido_Dar_la_Cuenta( Pedido this, float Precios_Pizzas[], float Precios_Bebidas[], float Precios_Postres[] ){

  float Total = 0;

  for( size_t i = 0; i < TIPOS ; ++i ){
    Total += this.Pizzas[ i ] * Precios_Pizzas[ i ];
  }

  for( size_t i = 0; i < SABORES ; ++i ){
    Total += this.Bebidas[ i ] * Precios_Bebidas[ i ];
  }

  for( size_t i = 0; i < EXTRAS ; ++i ){
    Total += this.Postres[ i ] * Precios_Postres[ i ];
  }
  
  return Total;
  
}

/**
 * This function searches for a specific pedido (order) with the given name within an array of pedidos (orders).
 * It iterates through the pedidos using a cursor and compares the name of each pedido with the given name.
 * 
 * @param this A pointer to the `Pedidos` object representing the array of pedidos.
 * @param Len The length of the pedidos array.
 * @param Name The name to search for.
 * 
 * @return A pointer to the `Pedido` object if a pedido with the given name is found, or NULL if not found.
 */
Pedido* Pedidos_Buscar_Pedido( Pedidos* this, int Len, char Name[NOMBRE_MAX] ){
  Pedido_CursorProximo( this );


  while( this->cursor != NULL){
    if( strcmp( this->cursor->data.Nombre, Name ) == 0){
      return this->cursor;
    }
    Pedido_CursorNext( this );
    
  }
  return NULL;
}

/**
 * This function adds the current time to a given pedido (order) by populating the Hora (time) structure
 * with the current hour, minutes, and seconds.
 * 
 * @param p A pointer to the `Pedido` object to which the current time will be added.
 * 
 * @return None.
 */
void Pedidos_agregarHoraPedido(Pedido* p) {
    // Obtener la hora actual
    time_t t = time(NULL);
    struct tm* tiempo_local = localtime(&t);
    
    // Asignar la hora actual al pedido
    p->Hora.horas = tiempo_local->tm_hour;
    p->Hora.minutos = tiempo_local->tm_min;
    p->Hora.segundos = tiempo_local->tm_sec;
}

/**
 * The ResumDia function prints and removes all the orders in a given list.
 * 
 * @param this a pointer to a Pedidos struct, which is likely a data 
 * structure that holds a collection of Pedido structs (orders).
 */
void Pedidos_ResumenDia( Pedidos* this ){
  assert( this );
  while ( Pedidos_IsEmpty( this ) != true )
    {
      Pedidos_Print_Pedido( this->last->data );
      Pedido_Quitar_PedidoBack( this );
      
    }
}

/**
 * This function prints the details of a pedido (order) object.
 * It prints the pedido number, name, and total amount.
 * 
 * @param this The pedido object to be printed.
 * 
 * @return None.
 */
void Pedidos_Print_Pedido ( Pedido this ){
  printf( "No. del pedido : %ld Nombre: %s Total: %f \n", this.Numero, this.Nombre, this.Total);
  
}

/**
 * This function updates the name of a pedido (order) object with the specified name.
 * 
 * @param this The pointer to the pedido object.
 * @param name The pointer to the name string.
 * 
 * @return None.
 */
void Pedidos_Nombre_Pedido( Pedido* this, char* name){
  strncpy( this->Nombre, name, NOMBRE_MAX);
}

/**
 * The function calculates the total sales for a given day by iterating 
 * through a linked list of orders.
 * 
 * @param this a pointer to a Pedidos struct, which presumably contains a 
 * linked list of Pedido structs.
 * 
 * @return a float value which represents the total sales of the day.
 */
void Pedidos_Venta_del_Dia( Pedidos* this){
  assert( this );
  Pedido_CursorProximo( this );


  while( this->cursor != NULL ){
    Pedidos_Print_Pedido( this->cursor->data );
    Pedido_CursorNext( this );
  }
}