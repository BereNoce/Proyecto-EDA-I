#include "Reloj.h"

/**
 * The function prints the time in hours, minutes, and seconds format.
 * 
 * @param this A pointer to a Reloj object, which is a user-defined data type 
 * representing a clock or a timepiece. The function Reloj_Imprime takes this pointer as an argument and prints the hours, minutes, and seconds of the clock in the format "hh:mm:ss".
 */
void Reloj_Imprime( const Reloj* this ){
   printf( "%02d:%02d:%02d\n", this->horas, this->minutos, this->segundos); 
}

/**
 * The function sets the hours of a clock object, with a limit of 23 hours and resetting to 0 if exceeded.
 * 
 * @param this a pointer to a Reloj object, which is a data structure 
 * representing a clock or timepiece
 * @param horas An integer value representing the hours of a clock.
 */
void Reloj_SetHoras( Reloj* this, int horas )
{
    assert( this );
    if (this->horas < 23)
    {
        this->horas = horas;
    }
    else
    {
        this->horas = 0;
    }

}

/**
 * The function sets the minutes of a clock object, resetting to 0 if the input is greater than or equal to 60.
 * 
 * @param this a pointer to a Reloj object, which is a data structure 
 * representing a clock or a timer.
 * @param minutos An integer value representing the number of minutes to set 
 * for a clock or timepiece.
 */
void Reloj_SetMinutos( Reloj* this, int minutos )
{
    assert( this );
    if (this->minutos < 60)
    {
        this->minutos = minutos;
    }
    else
    {
        this->minutos = 0;
    }


}

/**
 * The function sets the seconds of a clock object and resets to 0 if it 
 * exceeds 60.
 * 
 * @param this a pointer to a Reloj object, which is a user-defined data 
 * type representing a clock or timepiece.
 * @param segundos An integer value representing the number of seconds to set for a clock or timer.
 */
void Reloj_SetSegundos( Reloj* this, int segundos )
{
    assert( this );
    if (this->segundos < 60)
    {
        this->segundos = segundos;
    }
    else
    {
        this->segundos = 0;
    }


}

/**
 * The function creates a new instance of a clock with specified hours, 
 * minutes, and seconds.
 * 
 * @param horas an integer representing the hours of the clock
 * @param minutos The "minutos" parameter in the "Crear_Reloj" function is 
 * an integer value that represents the initial value for the minutes of the clock being created.
 * @param segundos The "segundos" parameter is an integer value representing the number of seconds in the time to be set for the clock.
 * 
 * @return The function `Crear_Reloj` is returning a pointer to a `Reloj` struct.
 */
Reloj* Crear_Reloj( int horas, int minutos, int segundos){
    
    Reloj* Creado = ( Reloj* ) malloc ( sizeof( Reloj ) );
    Reloj_SetHoras( Creado, horas );
    Reloj_SetMinutos( Creado, minutos );
    Reloj_SetSegundos( Creado, segundos );
    
    return Creado;
    
}  

/**
 * The function returns the value of the "horas" attribute of a given "Reloj" object.
 * 
 * @param this The "this" parameter is a pointer to an object of type "Reloj". This function is a
 * member function of the "Reloj" class, and it is used to get the value of the "horas" member variable
 * of the object pointed to by "this".
 * 
 * @return The function `Reloj_GetHoras` is returning the value of the `horas` member variable of the
 * `Reloj` object pointed to by `this`.
 */
int Reloj_GetHoras (Reloj* this){
    assert( this );
    return this->horas;
}

/**
 * The function returns the value of the "minutos" attribute of a given "Reloj" object.
 * 
 * @param this The "this" parameter is a pointer to an object of type "Reloj". This function is a
 * member function of the "Reloj" class and is used to get the value of the "minutos" data member of
 * the object pointed to by "this".
 * 
 * @return The function `Reloj_GetMinutos` is returning the value of the `minutos` attribute of the
 * `Reloj` object pointed to by `this`.
 */
int Reloj_GetMinutos (Reloj* this){
    assert( this );
    return this->minutos;
}

/**
 * The function returns the value of the "segundos" attribute of a given 
 * "Reloj" object.
 * 
 * @param this The "this" parameter is a pointer to an object of type 
 * "Reloj". This function is a member function of the "Reloj" class, and it 
 * is used to get the value of the "segundos" member variable of the object 
 * pointed to by "this".
 * 
 * @return The function `Reloj_GetSegundos` is returning the value of the 
 * `segundos` attribute of the `Reloj` object pointed to by `this`.
 */
int Reloj_GetSegundos (Reloj* this){
    assert( this );
    return this->segundos;
}


