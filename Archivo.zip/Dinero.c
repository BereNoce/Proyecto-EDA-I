#include "Dinero.h"

/**
 * The function uses dynamic programming to calculate the minimum number of 
 * coins needed to make a certain amount of change.
 * 
 * @param i The index of the current denomination being considered in the 
 * array "denom".
 * @param j The parameter "j" represents the amount of money that needs to be 
 * exchanged or the target amount for which the minimum number of coins needs 
 * to be calculated.
 * @param denom an array of denominations (coin or bill values) available for 
 * making change
 * @param tabla a 2D array used for dynamic programming to store previously 
 * calculated values
 * 
 * @return an integer value, which is the minimum number of coins needed to 
 * make the given amount 'j' using the denominations in the array 'denom'.
 */
int Dinero_cambio_pd( int i, int j, int denom[], int tabla[][MAX_CAMBIO] )
{
  int x, y = 0;
  if( i < 0 ){
     return INFINITO;
  }
  if( tabla[ i ][ j ] != -1 ){
     return tabla[ i ][ j ];
  } 
  x = Dinero_cambio_pd( i - 1 , j, denom, tabla);

  if( ( j - denom[ i ] ) < 0 ){
    y = INFINITO;
  }else{
    y = 1 + Dinero_cambio_pd( i, j - denom[ i ], denom, tabla );
  }
  if( x > y){
    tabla[ i ][ j ] = y; 
  }else{
    tabla[ i ][ j ] = x;  
  }
  return tabla[ i ][ j ]; 

}

/**
 * The function calculates the minimum number of coins needed to make change 
 * for a given amount using dynamic programming.
 * 
 * @param vuelto an integer representing the amount of change to be given back
 * @param denom an array of denominations (e.g. [1, 5, 10, 20] for MXN 
 * currency)
 * @param tabla a 2D array representing a table used for dynamic programming
 * @param filas The number of rows in the 2D array "tabla".
 * @param cols The maximum amount of change that can be given.
 * 
 * @return an integer value, which could be either the result of the function 
 * `cambio_pd` or -1 if the input `vuelto` is negative or greater than or 
 * equal to `cols`.
 */
int Dinero_cambio( int vuelto, int denom[], int tabla[][MAX_CAMBIO], int filas, int cols )
{
   if( vuelto < 0 || vuelto >= cols )
   {
      return -1;
   }

   if( tabla[0][0] == -1 )
   {
      // llena la primer columna con ceros:
      for( size_t i = 0; i < filas; ++i )
      {
         tabla[i][0] = 0;
      }

      // llena la primer fila:
      for( size_t i = 0; i < cols; ++i )
      {
         tabla[0][i] = i;
      }
   }

   return Dinero_cambio_pd( MAX_DENOMS - 1, vuelto, denom, tabla );
}

/**
 * The function calculates the minimum number of coins needed to make change 
 * for a given amount and stores the solution in an array of Moneda structures.
 * 
 * @param tabla a 2D array representing the dynamic programming table used to 
 * calculate the minimum number of coins needed to make change for a given 
 * amount.
 * @param vuelto The amount of change to be given back to the customer.
 * @param denom an array of denominations (coin values) in descending order
 * @param filas The number of rows in the 2D array "tabla".
 * @param cols The parameter "cols" is not used in this function and is not 
 * relevant to its execution.
 * @param conjunto_solucion an array of Moneda structures that will store the 
 * solution to the coin change problem.
 */
void Dinero_calcular_monedas(int tabla[][MAX_CAMBIO], int vuelto, int denom[], int filas, int cols, Dinero conjunto_solucion[])
{
   int i = filas - 1;
   int j = vuelto;
   int index = 0;

   while (i >= 0 && j > 0)
   {
      if (j >= denom[i] && tabla[i][j] == tabla[i][j - denom[i]] + 1)
      {
         conjunto_solucion[index].denom = denom[i];
         conjunto_solucion[index].quantity++;
         j -= denom[i];
      }
      else
      {
         i--;
         index++;
      }
   }
}
