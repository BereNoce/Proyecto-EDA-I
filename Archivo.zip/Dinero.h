#ifndef  DINERO_INC
#define  DINERO_INC

#include <stdio.h>
#include <stdlib.h>

#define INFINITO 10000
#define MAX_DENOMS 9
#define  MAX_CAMBIO 1000
#define MIN( x, y ) (x) < (y) ? (x) : (y)


typedef struct {
   int denom;
   int quantity;
} Dinero;


void Dinero_calcular_monedas(int tabla[][MAX_CAMBIO], int vuelto, int denom[], int filas, int cols, Dinero conjunto_solucion[]);
int Dinero_cambio_pd( int i, int j, int denom[], int tabla[][MAX_CAMBIO] );
int Dinero_cambio( int vuelto, int denom[], int tabla[][MAX_CAMBIO], int filas, int cols );

#endif
