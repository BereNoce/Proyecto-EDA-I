#include <stdio.h>
#include <stdlib.h>
#include "Producto.h"
#include "Pedido.h"
#include "Reloj.h"

#define NUM_DENOMINACIONES 7
#define FILAS 7
#define COLUMNAS 200
#define MAX_PRODUCTS 100
#define MAX_DENOMS 10

int main() {
    TAD_Productos productos;
    int numPrecios = 3;
    int num_monedas;
    Pedido Order1;  
    /*
    int denominaciones[NUM_DENOMINACIONES] = {1000, 100, 50, 20, 10, 5, 1};
    Dinero conjunto_solucion[MAX_DENOMS] = {0};
    int matriz[FILAS][COLUMNAS];
    for (int i = 0; i < FILAS; i++) {
        for (int j = 0; j < COLUMNAS; j++) {
            matriz[i][j] = -1;
        }
    }*/

    productos.productos = (Producto*)malloc(MAX_PRODUCTS * sizeof(Producto));
    productos.numProductos = 0;
    Producto_importarCSV(&productos);
    int inicio_del_dia;
    printf("/****Bienvenido a 'El rincón de la Pizza' ****/\n");

etiqueta10:
    printf("Presiona 1 para iniciar el día\n");
    scanf("%d", &inicio_del_dia);

    if (inicio_del_dia == 1) {
        Pedidos* Lista_de_Pedidos = Pedido_NewLista();
        float* PreciosPizzas = Producto_obtenerPreciosPizzas(&productos, &numPrecios);
        float* PreciosBebidas = Producto_obtenerPreciosBebidas(&productos, &numPrecios);
        float* PreciosPostres = Producto_obtenerPreciosPostres(&productos, &numPrecios);

        int respuesta1;
        int respuesta2;
        int respuesta3;
        int respuesta4;
        int respuesta5;
        int respuesta6;
        float respuesta7 = 0;
      
      
        size_t acum = 0;

    etiqueta1:
        printf("¿Qué deseas hacer?\n");
        printf("[1]Ver menús\n");
        printf("[2]Pedidos\n");
        printf("[3]Ver almacén\n");
        printf("[4]Finalizar día\n");
        scanf("%d", &respuesta1);

        switch (respuesta1) {
            case 1:
                do {
                    printf("¿Qué deseas hacer?\n");
                    printf("\n");
                    printf("[1]Ver menú Pizzas\n");
                    printf("[2]Ver menú Bebidas\n");
                    printf("[3]Ver menú Postres\n");
                    printf("\n");
                    printf("[0]Salir\n");
                    scanf("%d", &respuesta2);

                    switch (respuesta2) {
                        case 1:
                            Producto_mostrarPizzas(&productos);
                            break;
                        case 2:
                            Producto_mostrarBebidas(&productos);
                            break;
                        case 3:
                            Producto_mostrarPostres(&productos);
                            break;
                        case 0:
                            printf("Saliendo del menú.\n");
                            break;
                        default:
                            printf("Opción inválida. Por favor, ingrese una opción válida.\n");
                            break;
                    }
                } while (respuesta2 != 0);
                break;

            case 2:
            etiqueta2:
                do {
                    printf("¿Qué deseas hacer?\n");
                    printf("\n");
                    printf("[1]Realizar Pedido\n");
                    printf("[2]Ver pedidos\n");
                    printf("\n");
                    printf("[0]Salir\n");
                    scanf("%d", &respuesta3);

                    switch (respuesta3) {
                        case 1:
                            Order1 = Pedidos_Toma_De_Pedido(PreciosPizzas, PreciosBebidas, PreciosPostres, acum);        

                            Pedido_Agregar(Lista_de_Pedidos, Order1);
                            printf("La cuenta da: %0.2f\n", Order1.Total);
                            printf("Ingrese el monto a pagar\n");
                            scanf("%f", &respuesta7);
                          
                            respuesta7 = respuesta7 - Order1.Total;
                          /*
                            num_monedas = Dinero_cambio(respuesta7, denominaciones, matriz, NUM_DENOMINACIONES, COLUMNAS);

                            printf("Cambio: $%d, Monedas: %d\n", respuesta7, num_monedas);

                            Dinero_calcular_monedas(matriz, respuesta7, denominaciones, NUM_DENOMINACIONES, COLUMNAS, conjunto_solucion);
                            printf("\nConjunto solución óptimo de cambio:\n");
                            for (int i = 0; i < MAX_DENOMS; i++) {
                                if (conjunto_solucion[i].quantity > 0) {
                                    printf("(%d, %d)\t", conjunto_solucion[i].denom, conjunto_solucion[i].quantity);
                                }
                            } */
                            break;
                        case 2:
                            Pedidos_Venta_del_Dia(Lista_de_Pedidos);
                            break;
                        case 0:
                            printf("Saliendo del menú.\n");
                            break;
                        default:
                            printf("Opción inválida. Por favor, ingrese una opción válida.\n");
                            break;
                    }
                } while (respuesta3 != 0);
                break;

            case 3:
            etiqueta3:
                do {
                    printf("¿Qué deseas hacer?\n");
                    printf("\n");
                    printf("[1]Listar Productos\n");
                    printf("[2]Agregar Producto\n");
                    printf("[3]Eliminar Producto\n");
                    printf("[4]Modificar Producto\n");
                    printf("[5]Buscar Producto\n");
                    printf("\n");
                    printf("[0]Salir\n");
                    scanf("%d", &respuesta6);

                    switch (respuesta6) {
                        case 1:
                            Producto_listar(&productos);
                            break;
                        case 2:
                            Producto_agregar(&productos);
                            break;
                        case 3:
                            Producto_eliminar(&productos);
                            break;
                        case 4:
                            Producto_modificaciones(&productos);
                            break;
                        case 5:
                            Producto_buscar(&productos);
                            break;
                        case 0:
                            printf("Saliendo del menú.\n");
                            break;
                        default:
                            printf("Opción inválida. Por favor, ingrese una opción válida.\n");
                            break;
                    }
                } while (respuesta6 != 0);
                break;

            case 4:
            etiqueta5:
                do {
                    printf("¿Estás seguro de finalizar el día?\n");
                    printf("[1]Sí\n");
                    printf("[0]No\n");
                    scanf("%d", &respuesta5);

                    switch (respuesta5) {
                        case 1:
                            Pedidos_ResumenDia(Lista_de_Pedidos);
                            Pedido_Vaciar(Lista_de_Pedidos);
                            Pedido_DeleteLista(&Lista_de_Pedidos);
                            break;
                        case 0:
                            printf("Saliendo del menú.\n");
                            break;
                        default:
                            printf("Opción inválida. Por favor, ingrese una opción válida.\n");
                            break;
                    }
                } while (respuesta5 != 0);
                break;
        }
        goto etiqueta10;
    } else {
        goto etiqueta10;
    }
    free(productos.productos);
}
